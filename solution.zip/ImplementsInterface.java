
public class ImplementsInterface implements testinterface{

	
	ImplementsInterface()
	{
		System.out.println("execute constractor");
	}
	
	@Override
	public void method1() {
		// TODO Auto-generated method stub
		
		System.out.println("method1");
		
	}

	@Override
	public void method2() {
		System.out.println("method2");
		
		
	}
	
	
	

}
