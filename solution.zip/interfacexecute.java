
public class interfacexecute {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ImplementsInterface e = new ImplementsInterface();
		
	
		

	}

}
