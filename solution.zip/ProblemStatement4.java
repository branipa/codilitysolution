
public class ProblemStatement4 {

	public static void main(String[] args) {
		// Not required

	}

}
