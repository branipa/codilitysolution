
public class ProblemSeventeen17 {

	public static void main(String[] args) {
		// Easy not required to develope

	}

}
