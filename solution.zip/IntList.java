
public class IntList {
	
	  public int value;
	  public IntList next;
	  
	  IntList(int value)
	  {
		  this.value=value;
		  next = null;
		  
	  }

}
