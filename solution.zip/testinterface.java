
public interface testinterface {
	
	
	void method1();
	void method2();

}
