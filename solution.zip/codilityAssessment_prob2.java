
public class codilityAssessment_prob2 {

}
