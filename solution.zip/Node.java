
public class Node {
	
	int nodeValue;
    Node left, right;
    static int count=0; 
 
    	Node(int nodeValue) {
    	this.nodeValue = nodeValue;
        left  = null;
        right = null;
      //  System.out.println("Inside constructoer" + count);
    }
	

}
